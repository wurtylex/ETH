"""Figure 1 of the report "Refuting ETH": two networks.   Run: python3 make_figures.py   (needs matplotlib)
Figure 2 (fig-crossing.pdf) is taken unchanged from the longer write-up of the same argument."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle

HERE = os.path.dirname(os.path.abspath(__file__))
plt.rcParams.update({"font.family": "serif", "font.serif": ["cmr10"], "mathtext.fontset": "cm", "font.size": 11,
                     "axes.unicode_minus": False, "axes.formatter.use_mathtext": True, "pdf.fonttype": 42})
INK, GREY, LIGHT, BLUE_BG, ORANGE_BG = "#1a1a1a", "#6f6f6f", "#e9e9e9", "#dbe8f6", "#fbe6d3"
FS, FS_NOTE = 11, 10

def box(ax, x, y, w, h, text="", fc="white", ec=INK, lw=1.0, r=0.08, fs=FS, z=3):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle=f"round,pad=0,rounding_size={r}", fc=fc, ec=ec, lw=lw, zorder=z))
    if text: ax.text(x, y, text, ha="center", va="center", fontsize=fs, zorder=z + 1, color=INK)

def wires(ax, p, q, n, gap=0.055):
    (x1, y1), (x2, y2) = p, q
    dx, dy = x2 - x1, y2 - y1; L = (dx * dx + dy * dy) ** 0.5; nx, ny = -dy / L, dx / L
    for i in range(n):
        o = (i - (n - 1) / 2) * gap
        ax.plot([x1 + nx * o, x2 + nx * o], [y1 + ny * o, y2 + ny * o], color=INK, lw=1.0, zorder=1, solid_capstyle="butt")

def setup(ax, xlim, ylim):
    ax.set_xlim(*xlim); ax.set_ylim(*ylim); ax.set_aspect("equal"); ax.axis("off")

W, Hh = 6.3, 1.74
fig = plt.figure(figsize=(W, Hh))
# (a) a network on three vertices with strings of 2, 1 and 3 bits
ax = fig.add_axes([0.0, 0.0, 0.40, 1.0]); setup(ax, (0, 0.40 * W), (0, Hh))
v1, v2, v3 = (0.42, 1.36), (2.02, 1.36), (1.22, 0.46)
wires(ax, v1, v2, 2); wires(ax, v2, v3, 1); wires(ax, v1, v3, 3)
for (x, y), name in ((v1, r"$f_1$"), (v2, r"$f_2$"), (v3, r"$f_3$")):
    box(ax, x, y, 0.48, 0.36, name, fc=LIGHT)
ax.text(1.22, 1.46, r"$w_{12}$: 2 bits", ha="center", va="bottom", fontsize=FS_NOTE)
ax.text(1.76, 0.88, r"$w_{23}$: 1 bit", ha="left", va="center", fontsize=FS_NOTE)
ax.text(0.68, 0.88, r"$w_{13}$: 3 bits", ha="right", va="center", fontsize=FS_NOTE)
ax.text(1.22, 0.0, "(a)", ha="center", va="bottom", fontsize=FS)
# (b) the incidence network of a formula
ax = fig.add_axes([0.40, 0.0, 0.60, 1.0]); setup(ax, (0, 0.60 * W), (0, Hh))
xs = {1: (0.62, 1.36), 2: (0.62, 0.91), 3: (0.62, 0.46)}
cs = {1: (2.62, 1.36), 2: (2.62, 0.91), 3: (2.62, 0.46)}
for i, j in [(1, 1), (2, 1), (3, 1), (1, 2), (2, 2), (2, 3), (3, 3)]:
    (x1, y1), (x2, y2) = xs[i], cs[j]
    ax.plot([x1, x2 - 0.80], [y1, y2], color=INK, lw=1.0, zorder=1)
for i, (x, y) in xs.items():
    ax.add_patch(Circle((x, y), 0.19, fc=BLUE_BG, ec=INK, lw=1.0, zorder=3))
    ax.text(x, y, rf"$x_{i}$", ha="center", va="center", fontsize=FS, zorder=4)
labels = {1: r"$x_1\vee\neg x_2\vee x_3$", 2: r"$\neg x_1\vee x_2$", 3: r"$x_2\vee\neg x_3$"}
for j, (x, y) in cs.items():
    box(ax, x, y, 1.60, 0.36, labels[j], fc=ORANGE_BG)
ax.text(0.62, 1.59, "variables", ha="center", va="bottom", fontsize=FS_NOTE, color=GREY)
ax.text(2.62, 1.59, "clauses", ha="center", va="bottom", fontsize=FS_NOTE, color=GREY)
ax.text(1.62, 0.0, "(b)", ha="center", va="bottom", fontsize=FS)
fig.savefig(os.path.join(HERE, "fig-report-networks.pdf")); plt.close(fig)
